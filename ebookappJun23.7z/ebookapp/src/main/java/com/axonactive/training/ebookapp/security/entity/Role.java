package com.axonactive.training.ebookapp.security.entity;

public enum  Role {
	ROLE_ADMIN,
	ROLE_USER
}
