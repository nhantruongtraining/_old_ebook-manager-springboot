package com.axonactive.training.ebookapp.api;

public class UserResource {
}
