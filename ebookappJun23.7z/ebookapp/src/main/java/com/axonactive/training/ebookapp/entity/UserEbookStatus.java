package com.axonactive.training.ebookapp.entity;

public enum UserEbookStatus {
    READING,
    TO_BE_READ,
    COMPLETED,
    NONE
}
