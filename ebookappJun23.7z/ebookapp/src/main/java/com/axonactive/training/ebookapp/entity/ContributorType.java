package com.axonactive.training.ebookapp.entity;

public enum ContributorType {
    AUTHOR,
    CO_AUTHOR,
    EDITOR,
    ILLUSTRATOR,
    TRANSLATOR
}
